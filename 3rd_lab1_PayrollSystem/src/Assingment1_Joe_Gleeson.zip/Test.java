// Driver for Employee hierarchy

// Java core packages
import java.text.DecimalFormat;
import java.util.ArrayList;

import org.joda.time.Chronology;
import org.joda.time.DateTime;
import org.joda.time.chrono.CopticChronology;

// Java extension packages
import javax.swing.JOptionPane;

public class Test {
	
	
    // test Employee hierarchy
    public static void main(String args[]) throws UserException {
        Employee employee; // superclass reference
        String output = "";
        
  //joda time  test
        DateTime testDt = new DateTime();//creates datetime
        int month = testDt.getMonthOfYear(); // gets month
        
        DateTime year2017 = testDt.withYear(2017);//sets year as 2017 
        DateTime year2012 = testDt.withYear(2012);//testing for loop - 5 or more years ago
        
        
        DateTime bossS = new DateTime(2000);
        DateTime bossSD = bossS.withYear(2000); //assign startdate
        
        DateTime commS = new DateTime(2010);//creates commission start date
        DateTime commSD = commS.withYear(2010); // sets it as 2010
        		
        DateTime hourS = new DateTime(2015);
        DateTime hourSD = hourS.withYear(2015); // start date for hourly worker is 2015
        
        DateTime pieceS = new DateTime(2011);
        DateTime pieceSD = pieceS.withYear(2011); // start date for hourly worker is 2011
        
        Chronology calender = CopticChronology.getInstance(); // creates coptic calender
        
        
        //creates arraylist for employees
       ArrayList<Employee> new1 =new ArrayList<Employee>(10);
       
      //name , salary , start date//
        Boss boss = new Boss("John", "Smith", 800.0, bossSD);
        
        //for negative salary testing
     //  Boss boss = new Boss("John", "Smith", -800.0, bossSD);
        
        new1.add(boss); // adds boss to arraylist of type employee
        CommissionWorker commissionWorker =
                new CommissionWorker(
                "Sue", "Jones", 400.0, 3.0, 150, commSD);

        PieceWorker pieceWorker =
                new PieceWorker("Bob", "Lewis", 2.5, 200, pieceSD);

      //for negative salary testing
      // PieceWorker pieceWorker = new PieceWorker("Bob", "Lewis", -2.5, 200, pieceSD);
               
        
        HourlyWorker hourlyWorker =
                new HourlyWorker("Karen", "Price", 13.75, 40, hourSD);

        DecimalFormat precision2 = new DecimalFormat("0.00");

        
        
        
// Employee reference to a Boss
        employee = boss;
    
        try {
			output += employee.toString() + " earned $"
			        + precision2.format(employee.earnings()) + "\n"
			        + boss.toString() + " earned $"
			        + precision2.format(boss.earnings()) + "\n"
			        + "Start date for boss is the year "
			        + boss.getStartDate()+  "\n" 
			        + "Employee ID is : "
					+ boss.getEmployeeID() +   "\n";
		} catch (UserException e1) {
			 			output = "error in boss earnings ";
			System.err.println(e1.getLocalizedMessage());
			e1.printStackTrace();
		}//gets employeeID
        
        
        
        new1.add(boss); // adds boss to arraylist of type employee
   
        // Employee reference to a CommissionWorker
        employee = commissionWorker;

        try {
			output += employee.toString() + " earned $"
			        + precision2.format(employee.earnings()) + "\n"
			        + commissionWorker.toString() + " earned $"
			        + precision2.format(
			        + commissionWorker.earnings()) + "\n"
			        + "Start date for commission worker is the year "
			        + commissionWorker.getStartDate()+  "\n" 
			        + "Employee ID is : "
			        +commissionWorker.getEmployeeID() + "\n";   //gets employeeID
		} catch (UserException e1) {
			output = "error in commissionWorker earnings ";
			System.err.println(e1.getLocalizedMessage());
			e1.printStackTrace();
		}//gets employeeID
        
        new1.add(commissionWorker); 
        commissionWorker.getEmployeeID();//gets employeeID

        // Employee reference to a PieceWorker
        employee = pieceWorker;

        try {
			output += employee.toString() + " earned $"
			        + precision2.format(employee.earnings()) + "\n"
			        + pieceWorker.toString() + " earned $"
			        + precision2.format(pieceWorker.earnings()) + "\n"
			        + "Start date for piece worker is the year "
			        + pieceWorker.getStartDate()+  "\n" 
			        + "Employee ID is : "
			        + pieceWorker.getEmployeeID() + "\n";
		} catch (UserException e1) {
			output = "error in pieceWorker earnings ";
			System.err.println(e1.getLocalizedMessage());
			e1.printStackTrace();
		}//gets employeeID
        
        new1.add(pieceWorker); 
      
// Employee reference to an HourlyWorker
        employee = hourlyWorker;

        try {
			output += employee.toString() + " earned $"
			        + precision2.format(employee.earnings()) + "\n"
			        + hourlyWorker.toString() + " earned $"
			        + precision2.format(hourlyWorker.earnings()) + "\n"
			       	+ "Start date for hourly worker is the year "
			        + hourlyWorker.getStartDate()+  "\n" 
			        		 + "Employee ID is : "
					+ hourlyWorker.getEmployeeID() + "\n";
		} catch (UserException e1) {
			output = "error in hourlyWorker earnings ";
			System.err.println(e1.getLocalizedMessage());
			e1.printStackTrace();
		}//gets employeeID

        new1.add(hourlyWorker); 
        
        //looping through arraylist 
        //to tally up employee
        
        for(Employee e:new1){
        	//condition to test dates if join date is 5 years 
        	//give bonus of $200
        	if ( e.getStartDate().isBefore(year2012)){
        		System.out.println(e.getFirstName() +" "+ e.getLastName() + " has been given bonus ");
        		double newEarn = 0;
				try {
					newEarn = e.earnings() + 200; // adds 200 bonus
				} catch (UserException e1) {
					//prints to consol, allows to show other earnings if error in one
					System.out.println("error in earnings ");
					System.err.println(e1.getLocalizedMessage());
					e1.printStackTrace();
				} 
        		System.out.println(e.getFirstName() +" "+ e.getLastName() + " new earnings are " + newEarn  );
        	}
        	
        	
        }
        
        JOptionPane.showMessageDialog(null, output,
                "Demonstrating Polymorphism - Employee Salaries",
                JOptionPane.INFORMATION_MESSAGE);

        System.exit(0);
    }
} // end class Test
