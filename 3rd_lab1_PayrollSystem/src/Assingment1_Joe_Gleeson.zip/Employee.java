import org.joda.time.DateTime;

// Abstract base class Employee.

public abstract class Employee {

    private String firstName;
    private String lastName;
    private DateTime startDate;
    //
   private  static int employeeID;
   private int num; //counter
   

   

    // constructor
    public Employee(String first, String last, DateTime startDate) {
        firstName = first;
        lastName = last;
        this.startDate = startDate; //sets startdate as int (year only)
       
    }
    
    //gets start date
    public DateTime getStartDate(){
    	return startDate;
    }

    // get first name
    public String getFirstName() {
        return firstName;
    }

    // get last name
    public String getLastName() {
        return lastName;
    }

    public String toString() {
        return firstName + ' ' + lastName;
    }

    
    public abstract double earnings()throws UserException;
    
 // adds employee number
	public static int getEmployeeID() {
		employeeID ++;
		return employeeID;
	}
	public void setEmplyeeID(int id){
		this.employeeID = id;
		
	}
		
	
	
	
}
