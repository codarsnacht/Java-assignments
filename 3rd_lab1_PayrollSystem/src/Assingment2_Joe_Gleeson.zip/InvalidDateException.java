
public class InvalidDateException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4546130203584908555L;



	public InvalidDateException(String string) {
		
		super(string);

		
	}


	
	
}
